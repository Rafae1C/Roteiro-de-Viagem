HTML
- Hypertext
- Markup ("Marcação")
  - Tags
  - Elementos
- Language (Maneira de escrita)

CSS
> Cascading Style Sheet

JavaScript
- Interpretada pelo browser/navegador
- Dinâmica
- Orientado a objeto (Nome de uma variável ou um objeto de fato)
- ECMAScript trazendo inovações (Órgão regulamentador)

-------------------------------------------------------------------

Conceitos fundamentais de programação
- Comentários (Pedaços de informações desconsiderados)
- Declaração de variáveis
  - const (Informação que espera que não mude)
  - let (Informação que espera que mude em algum momento)
- Operadores
  - Atribuição (=)
  - Concatenação (+)
  - Matemática (+, -, ...)
- Tipos de dados
  - string ((), [], {})
  - number
  - boolean (true, false)
  - Date (Ano-mês-dia hora)
- Estrutura de dados
  - functions (Agrupa uma lógica ou um pequeno pedaço de código para reutilizar)
  - object
  - array (objetos em formato de lista)
- Controle de fluxo
  - if 
  - else
- Estrutura de repetição
  - for
- Manipulação e gestão dos dados
  - Conversão de dados

-------------------------------------------------------------------

Definição de Algoritmo
> Sequência de passos lógica e finita p/ resolução de problemas

Fases da resolução de um problema
01. Coletar os dados
02. Processar os dados
03. Apresentar os dados